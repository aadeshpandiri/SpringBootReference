package com.example.service;

import com.example.model.Product;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CartService {
    private final Map<Long, Integer> cart = new LinkedHashMap<>();
    private final ProductService productService;

    public CartService(ProductService productService) {
        this.productService = productService;
    }

    public synchronized void addItem(Long productId, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be > 0");
        // Ensure product exists
        productService.findById(productId);
        cart.merge(productId, quantity, Integer::sum);
    }

    public synchronized void removeItem(Long productId) {
        if (cart.remove(productId) == null) {
            throw new ResourceNotFoundException("Product not in cart: " + productId);
        }
    }

    public synchronized void clear() { cart.clear(); }

    public synchronized List<CartItem> getItems() {
        List<CartItem> items = new ArrayList<>();
        for (Map.Entry<Long, Integer> e : cart.entrySet()) {
            Product p = productService.findById(e.getKey());
            items.add(new CartItem(p.getId(), p.getName(), p.getPrice(), e.getValue()));
        }
        return items;
    }

    public static record CartItem(Long productId, String name, java.math.BigDecimal price, int quantity) {}
}
