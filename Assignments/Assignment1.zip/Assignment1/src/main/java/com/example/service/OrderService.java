package com.example.service;

import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.repository.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final CartService cartService;
    private final ProductService productService;
    private final OrderRepository orderRepository;

    public OrderService(CartService cartService, ProductService productService, OrderRepository orderRepository) {
        this.cartService = cartService;
        this.productService = productService;
        this.orderRepository = orderRepository;
    }

    @Transactional
    public Order placeOrder() {
        List<CartService.CartItem> cartItems = cartService.getItems();
        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        List<OrderItem> orderItems = cartItems.stream()
                .map(ci -> new OrderItem(ci.productId(), ci.quantity(), ci.price()))
                .collect(Collectors.toList());

        Order order = new Order();
        order.setItems(orderItems);
        order.setOrderDateTime(LocalDateTime.now());

        Order saved = orderRepository.save(order);
        cartService.clear();
        return saved;
    }

    public Optional<Order> getOrderById(long orderId) {
        return orderRepository.findById(orderId);
    }
}
