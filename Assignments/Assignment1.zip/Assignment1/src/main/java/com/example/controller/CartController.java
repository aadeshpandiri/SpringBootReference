package com.example.controller;

import com.example.service.CartService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {
	private final CartService cartService;

	public CartController(CartService cartService) { this.cartService = cartService; }

	public record AddCartItemRequest(Long productId, Integer quantity) {}

	@PostMapping
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void add(@RequestBody AddCartItemRequest req) {
		cartService.addItem(req.productId(), req.quantity() == null ? 1 : req.quantity());
	}

	@GetMapping
	public List<CartService.CartItem> list() { return cartService.getItems(); }

	@DeleteMapping("/{productId}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void remove(@PathVariable Long productId) { cartService.removeItem(productId); }
}
