package com.example;

import com.example.model.Product;
import com.example.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;

@SpringBootApplication
public class Assignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Application.class, args);
	}

	@Bean
	CommandLineRunner data(ProductRepository repo) {
		return args -> {
			if (repo.count() == 0) {
				repo.save(new Product("Laptop", "Thin and light", new BigDecimal("1200.00")));
				repo.save(new Product("Phone", "Latest smartphone", new BigDecimal("800.00")));
				repo.save(new Product("Headphones", "Noise cancelling", new BigDecimal("199.99")));
			}
		};
	}
}
