package com.example.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "order_date_time")
    private LocalDateTime orderDateTime;

    @ElementCollection
    @CollectionTable(name = "order_items", joinColumns = @JoinColumn(name = "order_id"))
    private List<OrderItem> items;

    public long getId() { return id; }
    public LocalDateTime getOrderDateTime() { return orderDateTime; }
    public List<OrderItem> getItems() { return items; }

    public void setId(long id) { this.id = id; }
    public void setOrderDateTime(LocalDateTime orderDateTime) { this.orderDateTime = orderDateTime; }
    public void setItems(List<OrderItem> items) { this.items = items; }
}
