package com.example.controller;

import com.example.model.CartItem;
import com.example.service.CartService;
import com.example.model.*;
import com.example.service.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/cart")
public class CartController {
    @Autowired
    private CartService cartService;

    @PostMapping
    public ResponseEntity<CartItem> addToCart(@RequestBody CartItem cartItem) {
        return new ResponseEntity<CartItem>(cartService.addToCart(cartItem), HttpStatus.CREATED);
    }

    @GetMapping
    public List<CartItem> getAllCartItems() {
        return cartService.getAllCartItems();
    }

    @DeleteMapping("{productId}")
    public ResponseEntity<String> deleteCartItem(@PathVariable("productId") long productId){
        boolean isRemoved=cartService.removeFromCart(productId);
        if(isRemoved){
            return new ResponseEntity<String>("Item removed from cart successfully.",HttpStatus.OK);
        }else {
            return new ResponseEntity<String>("Item not found in cart.",HttpStatus.NOT_FOUND);
        }
    }

}
