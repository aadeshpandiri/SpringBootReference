package com.example.client;

import com.example.model.Product;
import com.example.model.*;
import org.springframework.cloud.openfeign.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@FeignClient(name = "product-service")
public interface ProductClient {

    @GetMapping("/api/products/{id}")
    public Product getProductById(@PathVariable("id") Long id);

    @GetMapping("/api/products")
    public List<Product> getAllProducts();
}
