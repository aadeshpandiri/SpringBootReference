package com.example.controller;

import com.example.service.OrderService;
import com.example.model.*;
import com.example.service.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @PostMapping
    public ResponseEntity<Order> placeOrder() {
        return new ResponseEntity<Order>(orderService.placeOrder(), HttpStatus.CREATED);
    }

    @GetMapping("{orderId}")
    public Order getOrderById(@PathVariable("orderId") long orderId){
        return orderService.getOrderById(orderId).orElse(null);
    }
}
