package com.example.service;

import com.example.client.ProductClient;
import com.example.model.*;
import com.example.repository.OrderRepository;
import com.example.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductClient productClient;


    public Order placeOrder() {
        List<CartItem> cartItems = cartRepository.findAll();

        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cannot place order: Cart is empty.");
        }

        Order order = new Order();
        order.setOrderDateTime(LocalDateTime.now());

        List<OrderItem> orderItems = new ArrayList<>();

        for (CartItem cartItem : cartItems) {
            // Validate product existence and fetch details
            Product product = productClient.getProductById(cartItem.getProductId());
            if (product == null) {
                throw new RuntimeException("Product not found for ID: " + cartItem.getProductId());
            }

            OrderItem orderItem = new OrderItem();
            orderItem.setProductId(product.getId());
            orderItem.setProductName(product.getName());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(product.getPrice() * cartItem.getQuantity());
            orderItem.setOrder(order);

            orderItems.add(orderItem);
        }

        order.setItems(orderItems);

        // Save order (cascades items)
        Order savedOrder = orderRepository.save(order);

        // Clear the cart after successful order
        cartRepository.deleteAll();

        return savedOrder;
    }

    public Optional<Order> getOrderById(long orderId) {
        return orderRepository.findById(orderId);
    }
}
