package com.example.service;

import com.example.client.ProductClient;
import com.example.model.CartItem;
import com.example.model.Product;
import com.example.repository.CartRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductClient productClient;

    private static final String PRODUCT_SERVICE = "productService";

    @CircuitBreaker(name = PRODUCT_SERVICE, fallbackMethod = "fallbackAddToCart")
    public CartItem addToCart(CartItem cartItem) {
        long productId = cartItem.getProductId();

        Optional<Product> product = Optional.ofNullable(productClient.getProductById(productId));

        if (product.isPresent()) {
            Optional<CartItem> existingItem = cartRepository.findAll().stream()
                    .filter(item -> item.getProductId() == productId)
                    .findFirst();

            if (existingItem.isPresent()) {
                CartItem item = existingItem.get();
                item.setQuantity(item.getQuantity() + cartItem.getQuantity());
                return cartRepository.save(item);
            }

            return cartRepository.save(cartItem);
        } else {
            throw new RuntimeException("Product not found in Product Service with ID: " + productId);
        }
    }

    public CartItem fallbackAddToCart(CartItem cartItem, Throwable throwable) {
        System.err.println("Fallback for addToCart" + throwable.getMessage());
        return null;
    }

    public List<CartItem> getAllCartItems() {
        return cartRepository.findAll();
    }

    public boolean removeFromCart(long productId) {
        Optional<CartItem> item = cartRepository.findAll().stream()
                .filter(i -> i.getProductId() == productId)
                .findFirst();

        if (item.isPresent()) {
            cartRepository.delete(item.get());
            return true;
        }
        return false;
    }
}
