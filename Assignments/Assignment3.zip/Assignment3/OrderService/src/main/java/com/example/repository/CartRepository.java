package com.example.repository;

import com.example.model.CartItem;
import com.example.model.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.*;

@Repository
public interface CartRepository extends JpaRepository<CartItem,Long> {
}
